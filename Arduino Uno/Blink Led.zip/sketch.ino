#define ledRed1 2
void setup() {
  // put your setup code here, to run once:
  pinMode(ledRed1, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(ledRed1, HIGH);
  delay(500);
  digitalWrite(ledRed1, LOW);
  delay(500);
}
